/**
 * dx-signer
 *
 * Copyright 2022 北京顶象技术有限公司
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package fake.security;

import dx.channel.FixSha1WithDsaProvider;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;

public class Signature {
    private static final Provider fix = new FixSha1WithDsaProvider();

    public static java.security.Signature getInstance(String algorithm)
            throws NoSuchAlgorithmException {
        if ("SHA1WITHDSA".equalsIgnoreCase(algorithm)) {
            return java.security.Signature.getInstance(algorithm, fix);
        }
        return java.security.Signature.getInstance(algorithm);
    }

    public static java.security.Signature getInstance(String algorithm, String provider)
            throws NoSuchAlgorithmException, NoSuchProviderException {
        if ("SHA1WITHDSA".equalsIgnoreCase(algorithm)) {
            return java.security.Signature.getInstance(algorithm, fix);
        }
        return java.security.Signature.getInstance(algorithm, provider);
    }

    public static java.security.Signature getInstance(String algorithm, Provider provider)
            throws NoSuchAlgorithmException {
        if ("SHA1WITHDSA".equalsIgnoreCase(algorithm)) {
            return java.security.Signature.getInstance(algorithm, fix);
        }
        return java.security.Signature.getInstance(algorithm, provider);
    }
}
